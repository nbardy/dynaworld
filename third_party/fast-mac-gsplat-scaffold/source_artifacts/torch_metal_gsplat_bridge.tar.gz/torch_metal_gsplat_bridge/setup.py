from __future__ import annotations

import os
import sys
from pathlib import Path

from setuptools import setup, find_packages

try:
    from torch.utils.cpp_extension import BuildExtension, CppExtension
except Exception as exc:  # pragma: no cover
    raise RuntimeError("PyTorch is required to build this extension") from exc

ROOT = Path(__file__).resolve().parent
IS_DARWIN = sys.platform == "darwin"

sources = [
    str(ROOT / "csrc" / "bindings.cpp"),
]
extra_compile_args = {"cxx": ["-O3", "-std=c++17"]}
include_dirs = [str(ROOT / "csrc")]
extra_link_args = []

if IS_DARWIN:
    sources.append(str(ROOT / "csrc" / "metal" / "gsplat_metal.mm"))
    extra_compile_args["cxx"] += ["-ObjC++", "-fobjc-arc"]
    extra_link_args += [
        "-framework", "Foundation",
        "-framework", "Metal",
        "-framework", "MetalPerformanceShaders",
    ]

ext_modules = [
    CppExtension(
        name="torch_gsplat_bridge._C",
        sources=sources,
        include_dirs=include_dirs,
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
        define_macros=[("GSPAT_USE_METAL", "1")] if IS_DARWIN else [],
    )
]

setup(
    name="torch_metal_gsplat_bridge",
    version="0.1.0",
    packages=find_packages(),
    ext_modules=ext_modules,
    cmdclass={"build_ext": BuildExtension},
    zip_safe=False,
)
