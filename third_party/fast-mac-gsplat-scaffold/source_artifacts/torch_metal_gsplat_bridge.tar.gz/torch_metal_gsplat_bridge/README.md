# torch_metal_gsplat_bridge

PyTorch-first bridge scaffold for a custom Gaussian splat rasterizer with:

- Python autograd wrapper
- C++ operator registration
- Objective-C++ Metal backend entrypoints
- Metal shader source placeholders aligned to the MLX prototype ABI

This package is intentionally structured so the same Python API can dispatch to:

- `metal` on macOS / Apple Silicon
- `cuda` later, with the same tensor contracts

## Tensor contracts

Inputs:

- `means2d`: `[G, 2]` float32
- `conics`: `[G, 3]` float32 storing `[a, b, c]`
- `colors`: `[G, 3]` float32
- `opacities`: `[G]` float32
- `depths`: `[G]` float32

Output:

- image: `[H, W, 3]` float32

Backward returns grads for:

- `means2d`
- `conics`
- `colors`
- `opacities`

This version treats the sort permutation as piecewise constant. Depth gradients are zero.

## What is in here

- `torch_gsplat_bridge/rasterize.py`
  - user-facing Python API
  - autograd wrapper calling custom ops
- `csrc/bindings.cpp`
  - op schema registration
- `csrc/metal/gsplat_metal.mm`
  - Objective-C++ implementation and Metal dispatch scaffold
- `csrc/metal/gsplat_kernels.metal`
  - kernel source scaffold for:
    - snugbox/count
    - emit pairs
    - tile forward
    - tile backward

## Build note

This repo is source-only from the Linux sandbox. It is meant to be built on macOS with Xcode command line tools installed.
